# Хутір — Android-застосунок (Capacitor)

## Варіант А: зібрати APK на комп’ютері (Windows / Mac / Linux)
1. Встановіть **Android Studio** (https://developer.android.com/studio) і **Node.js 18+**.
2. Розпакуйте цю папку, у терміналі в ній: `npm install`
3. `npx cap open android` — відкриється Android Studio (або File → Open → папка `android`).
4. Дочекайтеся синхронізації Gradle (перший раз 5–10 хв, качає залежності).
5. Меню **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
   Готовий файл: `android/app/build/outputs/apk/debug/app-debug.apk`
6. Скиньте APK на телефон і встановіть (дозвольте «Встановлення з невідомих джерел»).
   Або під’єднайте телефон кабелем (USB-налагодження) і натисніть ▶ Run.

## Для Google Play
Build → Generate Signed Bundle / APK → Android App Bundle, створіть ключ (зберігайте його!) і завантажте .aab у Google Play Console (одноразово $25).

## Оновлення гри
Замініть `www/index.html` новою версією → `npx cap sync android` → знову Build.

## Без збірки
Відкрийте веб-версію гри в Chrome на Android → меню ⋮ → «Встановити застосунок» / «Додати на головний екран» — з’явиться іконка, гра відкриватиметься на весь екран і працюватиме офлайн.
