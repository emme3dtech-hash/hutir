# Хутір — iOS-застосунок (Capacitor)

Потрібно: Mac з Xcode 15+ і безкоштовний Apple ID (для встановлення на свій iPhone) або платний Apple Developer (для App Store / TestFlight).

1. Скопіюйте цю папку на Mac.
2. У Терміналі в цій папці: `npm install` (потрібен Node.js 18+).
3. `npx cap open ios` — відкриється Xcode (або відкрийте `ios/App/App.xcodeproj`).
4. У Xcode: ціль **App** → Signing & Capabilities → Team = ваш Apple ID; за потреби змініть Bundle Identifier (зараз `ua.storcheus.hutir`).
5. Під’єднайте iPhone кабелем, виберіть його вгорі й натисніть ▶ Run.
   На iPhone: Налаштування → Основні → VPN і керування пристроєм → довірити розробника.
6. Оновлення гри: замініть `www/index.html` новою версією і виконайте `npx cap sync ios`, потім знову Run.

Для App Store: Product → Archive → Distribute App (потрібен Apple Developer, $99/рік).
