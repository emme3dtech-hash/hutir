package ua.storcheus.hutir;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
